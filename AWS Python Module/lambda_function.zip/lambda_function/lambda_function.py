# Importing required libraries
import boto3
import io
import logging
import os
import pandas as pd
#from fastparquet import write

# Setting the logging functionality.
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)

# Reading the Environmental Variables
queue_name = os.environ['queue_name']

# Defining objects for respective services.
s3 = boto3.client('s3')
sqs_client = boto3.client('sqs')
sqs_resource = boto3.resource('sqs')

# Read csv file from the input folders.
def read_csv_file(bucket_name, file_key):
    """
    This function is to read the CSV file from the local folders and convert it to dataframe for further processing.
    :param file_path: The location for the input file path.
    :return: Returns the dataframe created out of the input CSV.
    """
    try:
        # Step to read the input csv file and convert the same to dataframe.
        file_obj = s3.get_object(Bucket=bucket_name, Key=file_key)
        csv_df = pd.read_csv(io.BytesIO(file_obj['Body'].read()), dtype=object)
        
        return csv_df

    except Exception as error:
        log.error("Error while reading csv: {} ".format(str(error)))
        log.error(log.traceback.format_exc())


def requested_stats(final_df):
    """
    This function is to read the final dataframe and populated values like hottest day,temp on that day and it's corresponding region..
    :param final_df: The final dataframe to be considered to populated the hottest day,temp and region values.
    :return: NA
    """
    try:
        # Pandas sql to generate the stats from the final dataframe i.e. as mentioned in the question.
        hottest_temp = final_df[['ObservationDate', 'Country', 'Region', 'ScreenTemperature']][final_df['ScreenTemperature'] == final_df['ScreenTemperature'].max()]
        log.info(hottest_temp.rename(columns={"ObservationDate": "Hottest_Date", "Country": "Hottest_Country", "Region": "Hottest_Region", "ScreenTemperature": "Max_Temp"}))

    except Exception as error:
        log.error("Error while performing stats: {} ".format(str(error)))
        log.error(logging.traceback.format_exc())
        

def lambda_handler(event, context):
    try:
        
        # Steps to read the data from the queue for the given customer group.
        queue_url_response = sqs_client.get_queue_url(
            QueueName=queue_name)
        queue_url = queue_url_response['QueueUrl']
        
        raw_data_final_df = pd.DataFrame()
        log.info('The Queue to be read is - {}'.format(str(queue_name)))
        queue_metadata_list = []
        
        # get messages information using SQS resource(max 10 messages at a time).
        queue_resource = sqs_resource.get_queue_by_name(QueueName=queue_name)
        while True:
            metadata_msgs_delete_list = []
            total_messages = queue_resource.receive_messages(
                MaxNumberOfMessages=10
                )
            #If clause is to break the while loop when there are no messages in the sqs queue.
            if len(total_messages) == 0:
                break
            else:
                for message in total_messages:
                    message_body = eval(message.body)
                    queue_metadata_list.append(message_body)
                    
                    # Store the receipt handle for all the messages to delete the messages later.
                    metadata_msgs_delete_list.append({'Id': message.message_id, 'ReceiptHandle': message.receipt_handle})
                    
                    # Capture the file related details from the S3 event messages being passed to the SQS queue.
                    bucket_name = message_body['Records'][0]['s3']['bucket']['name']
                    file_key = message_body['Records'][0]['s3']['object']['key']
                    file_name = file_key.split('/')[-1]
                    log.info("lambda_handler:Attempting to process file/s for :" + file_name)
                    job_input_file = "s3://{}/{}".format(bucket_name, file_key)
                    log.info(job_input_file)
                    
                    # Read the input csv file and convert the same into the dataframe.
                    raw_data_df = read_csv_file(bucket_name, file_key)
                    raw_data_final_df = raw_data_final_df.append(raw_data_df)
                    
                # Delete the messages from the queue as soon as we are done with receiving the messages.
                if len(metadata_msgs_delete_list) != 0:
                    delete_response = sqs_client.delete_message_batch(
                        QueueUrl=queue_url,
                        Entries=metadata_msgs_delete_list)
                        
        if len(queue_metadata_list) == 0:
            log.error("Queue is Empty")
            error_message_body = "Exiting Lambda since the Queue is Empty"
            log.info(error_message_body)
        
        else:
            if len(raw_data_final_df) > 1:
                # Listing the columns that we need for the final dataframe.Removed the unwanted columns from the input data.
                columns = ['ObservationTime', 'ObservationDate', 'ScreenTemperature', 'SignificantWeatherCode', 'SiteName', 'Region', 'Country']
        
                # Creating a new dataframe to only have the required columns from the input data.
                df_selected_cols = raw_data_final_df[columns]
        
                # Creating the final dataframe which will be then used to populated the stats. This is one level up to the input data i.e. aggregated with respect to date by considering all the 24 observation points.
                # Assumption :-  Considering -99 as unknown value.
                
                # converting the ScreenTemperature into float, since we are getting ScreenTemperature as string when messages are read from
                # file
                df_selected_cols['ScreenTemperature'] = df_selected_cols['ScreenTemperature'].astype(float)
                
                # Filtering the unknown rows
                df_filtered_rows = df_selected_cols[df_selected_cols.ScreenTemperature != -99]
                
                # Creating final dataset on top of the filtered rows.
                final_df = df_filtered_rows.groupby(['Country', 'Region', 'SiteName', 'ObservationDate'])["ScreenTemperature"].max().reset_index(drop=False)
        
                # Converting the final dataframe to parquet format.
                #s3_url = 's3://{}/output-data/final_output.parquet.gzip'.format(bucket_name)
                #final_df.to_parquet(s3_url, compression='gzip')
        
                # Calling the function to generate the stats mentioned in the question. This is an optional part as the final dataframe in the previous step should eb able to answer the questions.
                requested_stats(final_df)
                
            else:
                logging.error("Dataframe has no records except the headers")
                raise
    
    except Exception as error:
        log.error("Error while performing operation: {} ".format(str(error)))
        log.error(logging.traceback.format_exc())

    finally:
        log.info("Execution Complete")